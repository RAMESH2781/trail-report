# HackerOne Submission - Candidate #3 (Updated)

## Report Title

```
Security Control Bypass in Chia GUI Allows Renderer to Access Private Keys via getKeyDetails
```

## Asset

```
https://github.com/Chia-Network/chia-blockchain-gui (SOURCE_CODE)
```

## Weakness

```
CWE-863 (Incorrect Authorization)
```

## Severity

```
Critical (CVSS 3.1: 9.1, AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N)
```

## Submission Steps

1. Go to https://hackerone.com/chia_network
2. Click "Submit Report"
3. Select Asset: `https://github.com/Chia-Network/chia-blockchain-gui`
4. Enter title: `Security Control Bypass in Chia GUI Allows Renderer to Access Private Keys via getKeyDetails`
5. Select Weakness: `CWE-863 (Incorrect Authorization)`
6. Set Severity: `Critical`
7. Copy REPORT.md contents into Description field
8. Copy Impact section into Impact field
9. Attach evidence files from `evidence/` directory
10. Submit

## Package Contents

```
final_3candidate/
├── REPORT.md              ← Main report (copy into Description)
├── README.md              ← This file (submission instructions)
├── evidence/
│   ├── 01-webSocketBridge-block.txt
│   ├── 02-getKeyDetails-bypass.txt
│   ├── 03-sendCommand-raw-ws.txt
│   └── 04-ipc-callchain.txt
└── poc/
    └── README-PoC.md      ← Reproduction steps
```
