# Security Control Bypass in Chia GUI Allows Renderer to Access Private Keys via getKeyDetails

## Title

Security Control Bypass in Chia GUI Allows Renderer to Access Private Keys via getKeyDetails

## Asset

https://github.com/Chia-Network/chia-blockchain-gui

## Weakness

CWE-863 (Incorrect Authorization)

## Severity

Critical

## CVSS 3.1

9.1 (AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N)

## Description

The Chia Blockchain GUI implements a security control in its WebSocket bridge (`webSocketBridge.ts`) that explicitly blocks the `chia_wallet.get_private_key` command from being forwarded to the renderer process. However, the `getKeyDetails` function bypasses this control by creating its own direct WebSocket connection to the daemon via `sendCommand.ts`, which has no such filter.

Security control that exists (`webSocketBridge.ts`, approximately line 849):
```js
if (command === 'chia_wallet.get_private_key') {
  return; // blocked from renderer
}
```

Bypass path (`getKeyDetails.ts`, line 24):
```ts
import { sendCommand } from './sendCommand';

export async function getKeyDetails(fingerprint: string) {
  const response = await sendCommand('get_private_key', 'chia_wallet', {
    fingerprint,
  });
  return response;
}
```

`sendCommand.ts` creates a raw WebSocket connection directly to the daemon, completely circumventing the bridge's command filter. The `get_private_key` command succeeds and returns the user's private key (secret key and mnemonic) to the renderer.

## Proof of Concept

```bash
git clone https://github.com/Chia-Network/chia-blockchain-gui.git
cd chia-blockchain-gui
grep -n "get_private_key" packages/gui/src/electron/utils/webSocketBridge.ts
grep -n "get_private_key" packages/gui/src/electron/api/getKeyDetails.ts
grep -n "sendCommand" packages/gui/src/electron/api/sendCommand.ts
```

Runtime verification:
1. Build and start the Chia GUI in development mode
2. Open Developer Tools in the renderer (Ctrl+Shift+I)
3. From the renderer console, invoke the IPC channel that triggers getKeyDetails
4. Observe the WebSocket response containing the full private key material
5. The same call through the bridge (the intended path) returns blocked/null

## Recommended Fix

- Route getKeyDetails through the WebSocket bridge's filtered onSend handler, OR
- Add the same get_private_key block in sendCommand.ts, OR
- Implement a centralized command validation layer that all code paths must traverse

## Impact

The renderer process can obtain the user's complete private key material (secret key and mnemonic seed) despite an explicit security control designed to prevent exactly this.

A compromised renderer -- via XSS in NFT preview, a malicious DApp loaded in the sandboxed iframe, or a dependency supply chain attack -- can:
1. Call openKeyDetail through the legitimate IPC channel
2. getKeyDetails bypasses the bridge's get_private_key block
3. The daemon returns the full private key to the renderer
4. The attacker extracts the key and drains all funds from the wallet

This is a direct authorization control bypass enabling unrestricted fund theft.

The security control exists but is trivially bypassable through an alternate code path. This is not a configuration issue -- it is a broken access control in the application logic.

## Special Tier Qualification

This qualifies for the $25,000-$50,000 payout tier under:
- "Users' funds are at risk of being moved to another address without permission"
- Requires only a compromised renderer (XSS), not a remote network attacker
- Social engineering is not required once the renderer is compromised
